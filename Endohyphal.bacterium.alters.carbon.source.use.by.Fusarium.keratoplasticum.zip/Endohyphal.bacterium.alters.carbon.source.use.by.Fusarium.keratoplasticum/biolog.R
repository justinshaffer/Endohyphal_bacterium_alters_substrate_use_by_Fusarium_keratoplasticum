##############################################################################################################
##############################################################################################################
## Biolog FF Microplate Data Analysis - PS0362a EHB+ and EHB-
## 2016
## Justin P. Shaffer
## justinparkshaffer@gmail.com
##############################################################################################################
##############################################################################################################

# Convert raw plate reads (.csv) into tidy data for analysis.
##############################################################################################################

# You will need the following packages; you will also need to manually install the pacakge "bear":
install.packages("tidyr")
install.packages("ggplot2")
install.packages("reshape")
install.packages("reshape2")
install.packages("vegan")
install.packages("cluster")
install.packages("dendextend")
install.packages("indicspecies")
library(tidyr)
library(ggplot2)
library(bear)
library(reshape)
library(reshape2)
library(vegan)
library(cluster)
library(dendextend)
library(indicspecies)

# Set appropriate raw data file for analysis (pick Trial 01 or Trial 02)
data.in<- data.trial01 # Justin Shaffer Trial 01
data.in<- data.trial02 # Justin Shaffer Trial 02

# Set the number of plates in sheet (pick Trial 01 or Trial 02)
num.plates <- 300 # Justin Shaffer Trial 01
num.plates <- 282 # Justin Shaffer Trial 02

# Create your new data table headings
main <- data.frame(id = rep((1:96), num.plates), 
                          plate.id = "", 
                          well.row = "",
                          well.column = "",
                          substrate = "",
                          gross.abs = NA,
                          stringsAsFactors = FALSE)

# Add row letter IDs
main$well.row <- rep(rep(LETTERS[1:8], 12), num.plates)

# Add column number IDs
main$well.column <- rep(rep(1:12, each = 8), num.plates)

# Add "gross.abs" and "plate.id" to tidy data (we will split the latter next)
j <- 1
for (i in 1:num.plates) {
  # print(((96*i)-96) + 1)
  main$plate.id[(((96*i) - 96) + 1):(96*i)] <- rep(data.in[(i*10) - 9,1], 96)
  for (column.num in 1:12) {
    for (row.num in 1:8) {
      #main$gross.abs[j] <- data.in[(i*10) - (9 - row.num), column.num + 1] # Edit this line if gross.abs data are in another format
      main$gross.abs[j] <- data.in[(i*10) - (8 - row.num), column.num + 1]
      j <- j + 1
    }
  }
}

# Split plate.id column into separate columns (ehb, hour, day, wavelength, plate)
main<-separate(data=main, col=plate.id, into=c("ehb", "hour", "day", "wavelength", "plate"), sep="_", remove=TRUE)

# Add substrate information from file made in excel (substrates.default.order)
main$substrate<- rep(substrates.default.order$substrate, num.plates)

##############################################END OF SECTION##################################################

# Reformat tidied data matrix such that substrates are ordered by type. I made the file substrates.ordered in excel
##############################################################################################################

# Reorder substrates in main data matrix to match order in ordered substrate list
main$substrate<-factor(main$substrate, levels = substrates.ordered$substrate)

##############################################END OF SECTION##################################################

# Convert raw 490 absorbance reads to corrected 490 absorbance reads (c490).
##############################################################################################################

# Convert missing data to NA, to account for the missing 490 read - ***Specific to Justin Shaffer's data for Biolog Trial 01***
main$gross.abs[main$gross.abs == 0] <- NA

# Split wavelength into two columns and add non-numeric names
main <- spread(main, key = wavelength, value = gross.abs)
names(main) <- c("id", "ehb", "hour", "day", "plate", "well.row", "well.column", "substrate","OD490", "OD750")

# Perform correction caluclation (490 - 750) and add as new column
main$ODc490 <- main$OD490 - main$OD750

# Combnine columns for different wavelengths back into one
main <- gather (main, wavelength, gross.abs, OD490:ODc490, factor_key=T)

# Remove rows with wavelength = 490
main<-subset(main, wavelength=="ODc490" | wavelength=="OD750", drop=T)

# Remove rows with NA to account for missing 490 read - ***Specific to Justin Shaffer's data for Biolog Trial 01***
main<-main[!rowSums(is.na(main["gross.abs"])), ]

# Replace any negative ODc490 gross.abs values with 0. Some may be negative from the correction.
main$gross.abs <- ifelse(main$gross.abs < 0, 0, main$gross.abs)

##############################################END OF SECTION##################################################

##############################################################################################################
# Add columns for factor versions of some variables (for data analyses).
##############################################################################################################

# Create factor variables for ehb, plate, read, hour, day
main$ehb.f<-as.factor(main$ehb)
main$plate.f<-as.factor(main$plate)
main$hour.f<-as.factor(main$hour)
main$day.f<-as.factor(main$day)

##############################################END OF SECTION##################################################

##############################################################################################################
# Create standard error (SE) table (for line graphs).
##############################################################################################################

gross.abs_SE <- summarySE(main, measurevar="gross.abs", groupvars=c("ehb", "hour", "day", "substrate", "wavelength"))

##############################################END OF SECTION##################################################

##############################################################################################################
# Create summary statistics table for gross absorbance, across all substrates and times. Mean, SD, N.
##############################################################################################################

mean_gross.abs<-with(main, tapply(gross.abs, day.f:wavelength:ehb.f:substrate, mean))
sd_gross.abs<-with(main, tapply(gross.abs, day.f:wavelength:ehb.f:substrate, sd))
n_gross.abs<-with(main, tapply(gross.abs, day.f:wavelength:ehb.f:substrate, length))
table_gross.abs<-rbind(mean_gross.abs, sd_gross.abs, n_gross.abs)
write.csv(table_gross.abs, file = "Summary_table2.csv")

##############################################END OF SECTION##################################################

##############################################################################################################
# Subset data by wavelength, time point, or both
##############################################################################################################

# Create separate files for the two wavelengths
main.c490 <- subset(main, main$wavelength=="ODc490")
main.750 <- subset(main, main$wavelength=="OD750")

# Create separate files for the 15 time points.
##############################################################################################################

main.1<-main[which(main$day.f=="0"),]
main.2<-main[which(main$day.f=="0.5"),]
main.3<-main[which(main$day.f=="1"),]
main.4<-main[which(main$day.f=="1.5"),]
main.5<-main[which(main$day.f=="2"),]
main.6<-main[which(main$day.f=="2.5"),]
main.7<-main[which(main$day.f=="3"),]
main.8<-main[which(main$day.f=="3.5"),]
main.9<-main[which(main$day.f=="4"),]
main.10<-main[which(main$day.f=="4.5"),]
main.11<-main[which(main$day.f=="5"),]
main.12<-main[which(main$day.f=="5.5"),]
main.13<-main[which(main$day.f=="6"),]
main.14<-main[which(main$day.f=="6.5"),]
main.15<-main[which(main$day.f=="7"),]

# Create separate files for 15 time points within each wavelength
##############################################################################################################

main.c490.1<-main.c490[which(main.c490$day.f=="0"),]
main.c490.2<-main.c490[which(main.c490$day.f=="0.5"),]
main.c490.3<-main.c490[which(main.c490$day.f=="1"),]
main.c490.4<-main.c490[which(main.c490$day.f=="1.5"),]
main.c490.5<-main.c490[which(main.c490$day.f=="2"),]
main.c490.6<-main.c490[which(main.c490$day.f=="2.5"),]
main.c490.7<-main.c490[which(main.c490$day.f=="3"),]
main.c490.8<-main.c490[which(main.c490$day.f=="3.5"),]
main.c490.9<-main.c490[which(main.c490$day.f=="4"),]
main.c490.10<-main.c490[which(main.c490$day.f=="4.5"),]
main.c490.11<-main.c490[which(main.c490$day.f=="5"),]
main.c490.12<-main.c490[which(main.c490$day.f=="5.5"),]
main.c490.13<-main.c490[which(main.c490$day.f=="6"),]
main.c490.14<-main.c490[which(main.c490$day.f=="6.5"),]
main.c490.15<-main.c490[which(main.c490$day.f=="7"),]

main.750.1<-main.750[which(main.750$day.f=="0"),]
main.750.2<-main.750[which(main.750$day.f=="0.5"),]
main.750.3<-main.750[which(main.750$day.f=="1"),]
main.750.4<-main.750[which(main.750$day.f=="1.5"),]
main.750.5<-main.750[which(main.750$day.f=="2"),]
main.750.6<-main.750[which(main.750$day.f=="2.5"),]
main.750.7<-main.750[which(main.750$day.f=="3"),]
main.750.8<-main.750[which(main.750$day.f=="3.5"),]
main.750.9<-main.750[which(main.750$day.f=="4"),]
main.750.10<-main.750[which(main.750$day.f=="4.5"),]
main.750.11<-main.750[which(main.750$day.f=="5"),]
main.750.12<-main.750[which(main.750$day.f=="5.5"),]
main.750.13<-main.750[which(main.750$day.f=="6"),]
main.750.14<-main.750[which(main.750$day.f=="6.5"),]
main.750.15<-main.750[which(main.750$day.f=="7"),]

##############################################END OF SECTION##################################################

##############################################################################################################
# Perform Welch t-tests for pairwise comparisons, 750 data only.
##############################################################################################################

# Welch t-test. gross absorbance at 0 days, between EHB+ and EHB-, for water. There should be no difference.
##############################################################################################################

t0<-subset(main.750.1, main.750.1$substrate=="Water")
t.test(t0$gross.abs~t0$ehb)

# Welch t-tests. gross absorbance at 7 days, between EHB+ and EHB-, for each substrate.
##############################################################################################################

t1<-subset(main.750.15, main.750.15$substrate=="2-Keto-D-Gluconic.Acid")
t2<-subset(main.750.15, main.750.15$substrate=="Adenosine")
t3<-subset(main.750.15, main.750.15$substrate=="Adenosine-5'-Monophosphate")
t4<-subset(main.750.15, main.750.15$substrate=="Alaninamide")
t5<-subset(main.750.15, main.750.15$substrate=="alpha-Cyclodextrin")
t6<-subset(main.750.15, main.750.15$substrate=="alpha-D-Glucose")
t7<-subset(main.750.15, main.750.15$substrate=="alpha-D-Lactose")
t8<-subset(main.750.15, main.750.15$substrate=="alpha-Ketoglutaric.Acid")
t9<-subset(main.750.15, main.750.15$substrate=="Amygdalin")
t10<-subset(main.750.15, main.750.15$substrate=="Arbutin")
t11<-subset(main.750.15, main.750.15$substrate=="beta-Cyclodextrin")
t12<-subset(main.750.15, main.750.15$substrate=="beta-Hydroxybutyric.Acid")
t13<-subset(main.750.15, main.750.15$substrate=="Bromosuccinic.Acid")
t14<-subset(main.750.15, main.750.15$substrate=="D-Arabinose")
t15<-subset(main.750.15, main.750.15$substrate=="D-Arabitol")
t16<-subset(main.750.15, main.750.15$substrate=="D-Cellobiose")
t17<-subset(main.750.15, main.750.15$substrate=="D-Fructose")
t18<-subset(main.750.15, main.750.15$substrate=="D-Galactose")
t19<-subset(main.750.15, main.750.15$substrate=="D-Galacturonic.Acid")
t20<-subset(main.750.15, main.750.15$substrate=="D-Gluconic.Acid")
t21<-subset(main.750.15, main.750.15$substrate=="D-Glucosamine")
t22<-subset(main.750.15, main.750.15$substrate=="D-Glucuronic.Acid")
t23<-subset(main.750.15, main.750.15$substrate=="D-Lactic.Acid.Methyl.Ester")
t24<-subset(main.750.15, main.750.15$substrate=="D-Malic.Acid")
t25<-subset(main.750.15, main.750.15$substrate=="D-Mannitol")
t26<-subset(main.750.15, main.750.15$substrate=="D-Mannose")
t27<-subset(main.750.15, main.750.15$substrate=="D-Melezitose")
t28<-subset(main.750.15, main.750.15$substrate=="D-Melibiose")
t29<-subset(main.750.15, main.750.15$substrate=="D-Psicose")
t30<-subset(main.750.15, main.750.15$substrate=="D-Raffinose")
t31<-subset(main.750.15, main.750.15$substrate=="D-Ribose")
t32<-subset(main.750.15, main.750.15$substrate=="D-Saccharic.Acid")
t33<-subset(main.750.15, main.750.15$substrate=="D-Sorbitol")
t34<-subset(main.750.15, main.750.15$substrate=="D-Tagatose")
t35<-subset(main.750.15, main.750.15$substrate=="D-Trehalose")
t36<-subset(main.750.15, main.750.15$substrate=="D-Xylose")
t37<-subset(main.750.15, main.750.15$substrate=="Dextrin")
t38<-subset(main.750.15, main.750.15$substrate=="Ethanolamine")
t39<-subset(main.750.15, main.750.15$substrate=="Fumaric.Acid")
t40<-subset(main.750.15, main.750.15$substrate=="gamma-Aminobutyric.Acid")
t41<-subset(main.750.15, main.750.15$substrate=="gamma-Hydroxybutyric.Acid")
t42<-subset(main.750.15, main.750.15$substrate=="Gentiobiose")
t43<-subset(main.750.15, main.750.15$substrate=="Glucose-1-Phosphate")
t44<-subset(main.750.15, main.750.15$substrate=="Glucuronamide")
t45<-subset(main.750.15, main.750.15$substrate=="Glycerol")
t46<-subset(main.750.15, main.750.15$substrate=="Glycogen")
t47<-subset(main.750.15, main.750.15$substrate=="Glycyl-L-Glutamic.Acid")
t48<-subset(main.750.15, main.750.15$substrate=="i-Erythritol")
t49<-subset(main.750.15, main.750.15$substrate=="Isomaltulose")
t50<-subset(main.750.15, main.750.15$substrate=="L-Alanine")
t51<-subset(main.750.15, main.750.15$substrate=="L-Alanyl-Glycine")
t52<-subset(main.750.15, main.750.15$substrate=="L-Arabinose")
t53<-subset(main.750.15, main.750.15$substrate=="L-Asparagine")
t54<-subset(main.750.15, main.750.15$substrate=="L-Aspartic.Acid")
t55<-subset(main.750.15, main.750.15$substrate=="L-Fucose")
t56<-subset(main.750.15, main.750.15$substrate=="L-Glutamic.Acid")
t57<-subset(main.750.15, main.750.15$substrate=="L-Lactic.Acid")
t58<-subset(main.750.15, main.750.15$substrate=="L-Malic.Acid")
t59<-subset(main.750.15, main.750.15$substrate=="L-Ornithine")
t60<-subset(main.750.15, main.750.15$substrate=="L-Phenylalanine")
t61<-subset(main.750.15, main.750.15$substrate=="L-Proline")
t62<-subset(main.750.15, main.750.15$substrate=="L-Pyroglutamic.Acid")
t63<-subset(main.750.15, main.750.15$substrate=="L-Rhamnose")
t64<-subset(main.750.15, main.750.15$substrate=="L-Serine")
t65<-subset(main.750.15, main.750.15$substrate=="L-Sorbose")
t66<-subset(main.750.15, main.750.15$substrate=="L-Threonine")
t67<-subset(main.750.15, main.750.15$substrate=="Lactulose")
t68<-subset(main.750.15, main.750.15$substrate=="m-Inositol")
t69<-subset(main.750.15, main.750.15$substrate=="Maltitol")
t70<-subset(main.750.15, main.750.15$substrate=="Maltose")
t71<-subset(main.750.15, main.750.15$substrate=="Maltotriose")
t72<-subset(main.750.15, main.750.15$substrate=="Methyl.alpha-D-Galactoside")
t73<-subset(main.750.15, main.750.15$substrate=="Methyl.alpha-D-Glucoside")
t74<-subset(main.750.15, main.750.15$substrate=="Methyl.beta-D-Galactoside")
t75<-subset(main.750.15, main.750.15$substrate=="Methyl.beta-D-Glucoside")
t76<-subset(main.750.15, main.750.15$substrate=="N-Acetyl-D-Galactosamine")
t77<-subset(main.750.15, main.750.15$substrate=="N-Acetyl-D-Glucosamine")
t78<-subset(main.750.15, main.750.15$substrate=="N-Acetyl-D-Mannosamine")
t79<-subset(main.750.15, main.750.15$substrate=="N-Acetyl-L-Glutamic.Acid")
t80<-subset(main.750.15, main.750.15$substrate=="p-Hydroxyphenylacetic.Acid")
t81<-subset(main.750.15, main.750.15$substrate=="Putrescine")
t82<-subset(main.750.15, main.750.15$substrate=="Quinic.Acid")
t83<-subset(main.750.15, main.750.15$substrate=="Ribitol")
t84<-subset(main.750.15, main.750.15$substrate=="Salicin")
t85<-subset(main.750.15, main.750.15$substrate=="Sebacic.Acid")
t86<-subset(main.750.15, main.750.15$substrate=="Sedoheptulosan")
t87<-subset(main.750.15, main.750.15$substrate=="Stachyose")
t88<-subset(main.750.15, main.750.15$substrate=="Succinamic.Acid")
t89<-subset(main.750.15, main.750.15$substrate=="Succinic.Acid")
t90<-subset(main.750.15, main.750.15$substrate=="Succinic.Acid.Monomethyl.Ester")
t91<-subset(main.750.15, main.750.15$substrate=="Sucrose")
t92<-subset(main.750.15, main.750.15$substrate=="Turanose")
t93<-subset(main.750.15, main.750.15$substrate=="Tween.80")
t94<-subset(main.750.15, main.750.15$substrate=="Uridine")
t95<-subset(main.750.15, main.750.15$substrate=="Water")
t96<-subset(main.750.15, main.750.15$substrate=="Xylitol")

t.test(t1$gross.abs~t1$ehb)
t.test(t2$gross.abs~t2$ehb)
t.test(t3$gross.abs~t3$ehb)
t.test(t4$gross.abs~t4$ehb)
t.test(t5$gross.abs~t5$ehb)
t.test(t6$gross.abs~t6$ehb)
t.test(t7$gross.abs~t7$ehb)
t.test(t8$gross.abs~t8$ehb)
t.test(t9$gross.abs~t9$ehb)
t.test(t10$gross.abs~t10$ehb)
t.test(t11$gross.abs~t11$ehb)
t.test(t12$gross.abs~t12$ehb)
t.test(t13$gross.abs~t13$ehb)
t.test(t14$gross.abs~t14$ehb)
t.test(t15$gross.abs~t15$ehb)
t.test(t16$gross.abs~t16$ehb)
t.test(t17$gross.abs~t17$ehb)
t.test(t18$gross.abs~t18$ehb)
t.test(t19$gross.abs~t19$ehb)
t.test(t20$gross.abs~t20$ehb)
t.test(t21$gross.abs~t21$ehb)
t.test(t22$gross.abs~t22$ehb)
t.test(t23$gross.abs~t23$ehb)
t.test(t24$gross.abs~t24$ehb)
t.test(t25$gross.abs~t25$ehb)
t.test(t26$gross.abs~t26$ehb)
t.test(t27$gross.abs~t27$ehb)
t.test(t28$gross.abs~t28$ehb)
t.test(t29$gross.abs~t29$ehb)
t.test(t30$gross.abs~t30$ehb)
t.test(t31$gross.abs~t31$ehb)
t.test(t32$gross.abs~t32$ehb)
t.test(t33$gross.abs~t33$ehb)
t.test(t34$gross.abs~t34$ehb)
t.test(t35$gross.abs~t35$ehb)
t.test(t36$gross.abs~t36$ehb)
t.test(t37$gross.abs~t37$ehb)
t.test(t38$gross.abs~t38$ehb)
t.test(t39$gross.abs~t39$ehb)
t.test(t40$gross.abs~t40$ehb)
t.test(t41$gross.abs~t41$ehb)
t.test(t42$gross.abs~t42$ehb)
t.test(t43$gross.abs~t43$ehb)
t.test(t44$gross.abs~t44$ehb)
t.test(t45$gross.abs~t45$ehb)
t.test(t46$gross.abs~t46$ehb)
t.test(t47$gross.abs~t47$ehb)
t.test(t48$gross.abs~t48$ehb)
t.test(t49$gross.abs~t49$ehb)
t.test(t50$gross.abs~t50$ehb)
t.test(t51$gross.abs~t51$ehb)
t.test(t52$gross.abs~t52$ehb)
t.test(t53$gross.abs~t53$ehb)
t.test(t54$gross.abs~t54$ehb)
t.test(t55$gross.abs~t55$ehb)
t.test(t56$gross.abs~t56$ehb)
t.test(t57$gross.abs~t57$ehb)
t.test(t58$gross.abs~t58$ehb)
t.test(t59$gross.abs~t59$ehb)
t.test(t60$gross.abs~t60$ehb)
t.test(t61$gross.abs~t61$ehb)
t.test(t62$gross.abs~t62$ehb)
t.test(t63$gross.abs~t63$ehb)
t.test(t64$gross.abs~t64$ehb)
t.test(t65$gross.abs~t65$ehb)
t.test(t66$gross.abs~t66$ehb)
t.test(t67$gross.abs~t67$ehb)
t.test(t68$gross.abs~t68$ehb)
t.test(t69$gross.abs~t69$ehb)
t.test(t70$gross.abs~t70$ehb)
t.test(t71$gross.abs~t71$ehb)
t.test(t72$gross.abs~t72$ehb)
t.test(t73$gross.abs~t73$ehb)
t.test(t74$gross.abs~t74$ehb)
t.test(t75$gross.abs~t75$ehb)
t.test(t76$gross.abs~t76$ehb)
t.test(t77$gross.abs~t77$ehb)
t.test(t78$gross.abs~t78$ehb)
t.test(t79$gross.abs~t79$ehb)
t.test(t80$gross.abs~t80$ehb)
t.test(t81$gross.abs~t81$ehb)
t.test(t82$gross.abs~t82$ehb)
t.test(t83$gross.abs~t83$ehb)
t.test(t84$gross.abs~t84$ehb)
t.test(t85$gross.abs~t85$ehb)
t.test(t86$gross.abs~t86$ehb)
t.test(t87$gross.abs~t87$ehb)
t.test(t88$gross.abs~t88$ehb)
t.test(t89$gross.abs~t89$ehb)
t.test(t90$gross.abs~t90$ehb)
t.test(t91$gross.abs~t91$ehb)
t.test(t92$gross.abs~t92$ehb)
t.test(t93$gross.abs~t93$ehb)
t.test(t94$gross.abs~t94$ehb)
t.test(t95$gross.abs~t95$ehb)
t.test(t96$gross.abs~t96$ehb)

##############################################END OF SECTION##################################################

##############################################################################################################
# Correction for multiple comparisons - Adjusting p-values from t-tests using Benjamini & Hotchberg's 
# False Discovery Rate. You must first create a vector of p-values to be corrected which I created in
# excel and then import using the first line below.
##############################################################################################################

# 7 d. I created the file (t.test.p.values.7) in excel, with the p-values from each t-test
t.test.p.values.7.adjusted<-p.adjust(t.test.p.values.7$p, method="BH", n=96)
write.table(t.test.p.values.7.adjusted, "t.test.p.values.7d.adjusted.txt", sep="\t")

##############################################END OF SECTION##################################################

##############################################################################################################
# Line graphs. gross absorbance for both wavelengths across the seven days of the experiment
##############################################################################################################

# Visualize plots for all substrates at once
##############################################################################################################
pd<-position_dodge(0.1)
ggplot(gross.abs_SE, aes(x=day, y=gross.abs, colour=wavelength, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=wavelength:ehb), size=.25) + 
  #geom_point(position=pd, size=1, shape=21, fill="white") +
  geom_point(position=pd, size=.25, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=12) +
  theme_bw() +
  theme(text=element_text(size=7)) +
  xlab("Day") +
  ylab("Absorbance") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1")) +
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=1, colour="black",position=pd, size=0.1)
  
# Visualize plots for substrates divided into four groups, for visual clarity. Each group will be plotted on
# a single graph.
##############################################################################################################

# I created the file (substrate.groups) in excel and then import it using the line
# below. Columns are groups (g1, g2, g3, g4).

# Plot for group 1.
pd<-position_dodge(0.1)
ggplot(gross.abs_SE[gross.abs_SE$substrate %in% substrate.groups$g1,], aes(x=day, y=gross.abs, colour=wavelength, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=wavelength:ehb), size=0.25) + 
  #geom_point(position=pd, size=1, shape=21, fill="white") +
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1"))+
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black",size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))
  
# Plot for group 2.
pd<-position_dodge(0.1)
ggplot(gross.abs_SE[gross.abs_SE$substrate %in% substrate.groups$g2,], aes(x=day, y=gross.abs, colour=wavelength, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=wavelength:ehb), size=0.25) + 
  #geom_point(position=pd, size=1, shape=21, fill="white") +
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1"))+
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black",size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

# Plot for group 3
pd<-position_dodge(0.1)
ggplot(gross.abs_SE[gross.abs_SE$substrate %in% substrate.groups$g3,], aes(x=day, y=gross.abs, colour=wavelength, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=wavelength:ehb), size=0.25) + 
  #geom_point(position=pd, size=1, shape=21, fill="white") +
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1"))+
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black",size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

# Plot for group 4
pd<-position_dodge(0.1)
ggplot(gross.abs_SE[gross.abs_SE$substrate %in% substrate.groups$g4,], aes(x=day, y=gross.abs, colour=wavelength, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=wavelength:ehb), size=0.25) + 
  #geom_point(position=pd, size=1, shape=21, fill="white") +
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1"))+
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black",size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

##############################################END OF SECTION##################################################

##############################################################################################################
# Line graphs. gross.abs, 750 data only, across the seven days of the experiment.
##############################################################################################################

# Visualize plots for all substrates at once
##############################################################################################################
gross.abs_SE.750 <- subset(gross.abs_SE, gross.abs_SE$wavelength=="OD750")
pd<-position_dodge(0.1)
ggplot(gross.abs_SE.750, aes(x=day, y=gross.abs, colour=ehb, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=ehb), size=.25) + 
  geom_point(position=pd, size=.25, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=12) +
  theme_bw() +
  theme(text=element_text(size=7)) +
  xlab("Day") +
  ylab("Absorbance at 750 nm") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1")) +
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=1, colour="black", size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

# Plot data divided into four groups for visual clarity
##############################################################################################################

# Plot for group 1.
gross.abs_SE.750 <- subset(gross.abs_SE, gross.abs_SE$wavelength=="750")
pd<-position_dodge(0.1)
ggplot(gross.abs_SE.750[gross.abs_SE.750$substrate %in% substrate.groups$g1,], aes(x=day, y=gross.abs, colour=ehb, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=ehb), size=.25) + 
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance at 750 nm") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1")) +
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black", size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))
  
# Plot for group 2.
gross.abs_SE.750 <- subset(gross.abs_SE, gross.abs_SE$wavelength=="750")
pd<-position_dodge(0.1)
ggplot(gross.abs_SE.750[gross.abs_SE.750$substrate %in% substrate.groups$g2,], aes(x=day, y=gross.abs, colour=ehb, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=ehb), size=.25) + 
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance at 750 nm") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1")) +
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black", size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

# Plot for group 3.
gross.abs_SE.750 <- subset(gross.abs_SE, gross.abs_SE$wavelength=="750")
pd<-position_dodge(0.1)
ggplot(gross.abs_SE.750[gross.abs_SE.750$substrate %in% substrate.groups$g3,], aes(x=day, y=gross.abs, colour=ehb, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=ehb), size=.25) + 
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance at 750 nm") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1")) +
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black", size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

# Plot for group 4.
gross.abs_SE.750 <- subset(gross.abs_SE, gross.abs_SE$wavelength=="750")
pd<-position_dodge(0.1)
ggplot(gross.abs_SE.750[gross.abs_SE.750$substrate %in% substrate.groups$g4,], aes(x=day, y=gross.abs, colour=ehb, group=ehb)) +
  geom_line(position=pd, aes(linetype=ehb, group=ehb), size=.25) + 
  geom_point(position=pd, size=1, aes(shape=ehb)) +
  scale_shape_manual(values=c(19,1)) +
  facet_wrap(~substrate, ncol=5) +
  theme_bw() +
  theme(text=element_text(size=16)) +
  xlab("Day") +
  ylab("Absorbance at 750 nm") +
  ggtitle("Substrate Use") +
  scale_color_manual(values=c("royalblue3", "orangered1")) +
  geom_vline(xintercept=6.5, color="grey60", size=0.1) +
  geom_hline(yintercept=0.3, color="grey60", size=0.1) +
  geom_errorbar(aes(ymin=gross.abs-se, ymax=gross.abs+se), width=0.5, colour="black", size=0.1, position=pd) +
  scale_y_continuous(limits=c(0,2.6), breaks=c(0,1,2))

##############################################END OF SECTION##################################################

##############################################################################################################
# Correlation analysis - Relationship between c490 vs. 750 over the seven days of the experiment
##############################################################################################################

# Remove rows with wavelength = 490. We will use corrected 490 values = 490 - 750.
main.r<-subset(main.r, wavelength=="c490" | wavelength=="750", drop=T)

# Create factor variables for plate, hour, day
main.r$plate.f<-as.factor(main.r$plate)
main.r$hour.f<-as.factor(main.r$hour)
main.r$day.f<-as.factor(main.r$day)

# Convert data from long to wide, showing c490 and 750 values as separate columns
main.r.wide<-dcast(main.r, plate.f + day.f + ehb + substrate ~ wavelength, value.var="gross.abs")

# Plot c490 values by 750 values
ggplot(main.r.wide, aes(x=main.r.wide[,5], y=main.r.wide[,6])) +
  geom_point(shape=1, colour="royalblue3") +
  theme_classic() +
  theme(text=element_text(size=20)) +
  xlab("OD at 750 nm") +
  ylab("OD at c490 nm") +
  ggtitle("Relationship between\nc490 and 750 nm") +
  geom_smooth(method="lm", se=T, colour=" black")

# Plot c490 values by 750 values - both log transformed
ggplot(main.r.wide, aes(x=log(main.r.wide[,5]), y=log(main.r.wide[,6]))) +
  geom_point(shape=1, colour="royalblue3") +
  theme_classic() +
  theme(text=element_text(size=20)) +
  xlab("log OD at 750 nm") +
  ylab("log OD at c490 nm") +
  ggtitle("Relationship between\nc490 and 750 nm") +
  geom_smooth(method="lm", se=T, colour=" black")

# Correlation using log transformed data
cor.test(log(main.r.wide[,5]), log(main.r.wide[,6]), method = "pearson")
cor.test(log(main.r.wide[,5]), log(main.r.wide[,6]), method = "spearman")
cor.test(log(main.r.wide[,5]), log(main.r.wide[,6]), method = "kendall")

##############################################END OF SECTION##################################################

##############################################################################################################
# Multivariate analyses. Create cluster dendrograms, NMS ordination, ANOSIM, PerMANOVA, and MRPP
# to explore global differences between EHB+ and EHB- strains.
##############################################################################################################

# Create wide-format matrices for analyses in vegan, perform NMS, ANOSIM, PerMANOVA, MRPP, 
# and hierarchical clustering, for each time point.
##############################################################################################################

##############################################################################################################
# 0.5 day
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.2.wide<-dcast(main.2, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.2.wide.c490 <- subset(main.2.wide, main.2.wide$wavelength=="c490")
main.2.wide.750 <- subset(main.2.wide, main.2.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.2.wide.c490.meta<-subset(main.2.wide.c490[c(1:3)])
main.2.wide.750.meta<-subset(main.2.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.2.wide.c490<-within(main.2.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.2.wide.c490.reduced<-subset(main.2.wide.c490[c(-1,-2,-3)])
main.2.wide.c490.reduced.names<-main.2.wide.c490.reduced[,-97]
rownames(main.2.wide.c490.reduced.names)<-main.2.wide.c490.reduced[,97]

main.2.wide.750<-within(main.2.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.2.wide.750.reduced<-subset(main.2.wide.750[c(-1,-2,-3)])
main.2.wide.750.reduced.names<-main.2.wide.750.reduced[,-97]
rownames(main.2.wide.750.reduced.names)<-main.2.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.2.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 0.5 day")

# NMS ordination for 750 data
ord.750<-metaMDS(main.2.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 0.5 day")

# ANOSIM on the effect of EHB for c490 data
anosim(main.2.wide.c490.reduced.names, main.2.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.2.wide.750.reduced.names, main.2.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.2.wide.750.reduced.names~main.2.wide.750.meta$ehb, data=main.2.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.2.wide.750.reduced.names, main.2.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.2.c490<-vegdist(main.2.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.2.c490.clusters<-hclust(dist.2.c490)
dist.2.c490.dendro<- as.dendrogram(dist.2.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.2.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 0.5 day, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.2.750<-vegdist(main.2.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.2.750.clusters<-hclust(dist.2.750)
dist.2.750.dendro<- as.dendrogram(dist.2.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.2.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 0.5 day, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 1 day
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.3.wide<-dcast(main.3, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.3.wide.c490 <- subset(main.3.wide, main.3.wide$wavelength=="c490")
main.3.wide.750 <- subset(main.3.wide, main.3.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.3.wide.c490.meta<-subset(main.3.wide.c490[c(1:3)])
main.3.wide.750.meta<-subset(main.3.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.3.wide.c490<-within(main.3.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.3.wide.c490.reduced<-subset(main.3.wide.c490[c(-1,-2,-3)])
main.3.wide.c490.reduced.names<-main.3.wide.c490.reduced[,-97]
rownames(main.3.wide.c490.reduced.names)<-main.3.wide.c490.reduced[,97]

main.3.wide.750<-within(main.3.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.3.wide.750.reduced<-subset(main.3.wide.750[c(-1,-2,-3)])
main.3.wide.750.reduced.names<-main.3.wide.750.reduced[,-97]
rownames(main.3.wide.750.reduced.names)<-main.3.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.3.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 1 day")

# NMS ordination for 750 data
ord.750<-metaMDS(main.3.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 1 day")

# ANOSIM on the effect of EHB for c490 data
anosim(main.3.wide.c490.reduced.names, main.3.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.3.wide.750.reduced.names, main.3.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.3.wide.750.reduced.names~main.3.wide.750.meta$ehb, data=main.3.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.3.wide.750.reduced.names, main.3.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.3.c490<-vegdist(main.3.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.3.c490.clusters<-hclust(dist.3.c490)
dist.3.c490.dendro<- as.dendrogram(dist.3.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.3.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 1 day, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.3,0))

# Clustering - create distance matrix for 750 data
dist.3.750<-vegdist(main.3.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.3.750.clusters<-hclust(dist.3.750)
dist.3.750.dendro<- as.dendrogram(dist.3.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.3.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 1 day, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.12,0))

##############################################################################################################
# 1.5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.4.wide<-dcast(main.4, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.4.wide.c490 <- subset(main.4.wide, main.4.wide$wavelength=="c490")
main.4.wide.750 <- subset(main.4.wide, main.4.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.4.wide.c490.meta<-subset(main.4.wide.c490[c(1:3)])
main.4.wide.750.meta<-subset(main.4.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.4.wide.c490<-within(main.4.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.4.wide.c490.reduced<-subset(main.4.wide.c490[c(-1,-2,-3)])
main.4.wide.c490.reduced.names<-main.4.wide.c490.reduced[,-97]
rownames(main.4.wide.c490.reduced.names)<-main.4.wide.c490.reduced[,97]

main.4.wide.750<-within(main.4.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.4.wide.750.reduced<-subset(main.4.wide.750[c(-1,-2,-3)])
main.4.wide.750.reduced.names<-main.4.wide.750.reduced[,-97]
rownames(main.4.wide.750.reduced.names)<-main.4.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.4.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 1.5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.4.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 1.5 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.4.wide.c490.reduced.names, main.4.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.4.wide.750.reduced.names, main.4.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.4.wide.750.reduced.names~main.4.wide.750.meta$ehb, data=main.4.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.4.wide.750.reduced.names, main.4.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.4.c490<-vegdist(main.4.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.4.c490.clusters<-hclust(dist.4.c490)
dist.4.c490.dendro<- as.dendrogram(dist.4.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.4.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 1.5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.25,0))

# Clustering - create distance matrix for 750 data
dist.4.750<-vegdist(main.4.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.4.750.clusters<-hclust(dist.4.750)
dist.4.750.dendro<- as.dendrogram(dist.4.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.4.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 1.5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.12,0))

##############################################################################################################
# 2 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.5.wide<-dcast(main.5, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.5.wide.c490 <- subset(main.5.wide, main.5.wide$wavelength=="c490")
main.5.wide.750 <- subset(main.5.wide, main.5.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.5.wide.c490.meta<-subset(main.5.wide.c490[c(1:3)])
main.5.wide.750.meta<-subset(main.5.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.5.wide.c490<-within(main.5.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.5.wide.c490.reduced<-subset(main.5.wide.c490[c(-1,-2,-3)])
main.5.wide.c490.reduced.names<-main.5.wide.c490.reduced[,-97]
rownames(main.5.wide.c490.reduced.names)<-main.5.wide.c490.reduced[,97]

main.5.wide.750<-within(main.5.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.5.wide.750.reduced<-subset(main.5.wide.750[c(-1,-2,-3)])
main.5.wide.750.reduced.names<-main.5.wide.750.reduced[,-97]
rownames(main.5.wide.750.reduced.names)<-main.5.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.5.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 2 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.5.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 2 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.5.wide.c490.reduced.names, main.5.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.5.wide.750.reduced.names, main.5.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.5.wide.750.reduced.names~main.5.wide.750.meta$ehb, data=main.5.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.5.wide.750.reduced.names, main.5.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.5.c490<-vegdist(main.5.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.5.c490.clusters<-hclust(dist.5.c490)
dist.5.c490.dendro<- as.dendrogram(dist.5.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.5.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 2 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.25,0))

# Clustering - create distance matrix for 750 data
dist.5.750<-vegdist(main.5.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.5.750.clusters<-hclust(dist.5.750)
dist.5.750.dendro<- as.dendrogram(dist.5.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.5.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 2 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.12,0))

##############################################################################################################
# 2.5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.6.wide<-dcast(main.6, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.6.wide.c490 <- subset(main.6.wide, main.6.wide$wavelength=="c490")
main.6.wide.750 <- subset(main.6.wide, main.6.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.6.wide.c490.meta<-subset(main.6.wide.c490[c(1:3)])
main.6.wide.750.meta<-subset(main.6.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.6.wide.c490<-within(main.6.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.6.wide.c490.reduced<-subset(main.6.wide.c490[c(-1,-2,-3)])
main.6.wide.c490.reduced.names<-main.6.wide.c490.reduced[,-97]
rownames(main.6.wide.c490.reduced.names)<-main.6.wide.c490.reduced[,97]

main.6.wide.750<-within(main.6.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.6.wide.750.reduced<-subset(main.6.wide.750[c(-1,-2,-3)])
main.6.wide.750.reduced.names<-main.6.wide.750.reduced[,-97]
rownames(main.6.wide.750.reduced.names)<-main.6.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.6.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 2.5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.6.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 2.5 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.6.wide.c490.reduced.names, main.6.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.6.wide.750.reduced.names, main.6.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.6.wide.750.reduced.names~main.6.wide.750.meta$ehb, data=main.6.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.6.wide.750.reduced.names, main.6.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.6.c490<-vegdist(main.6.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.6.c490.clusters<-hclust(dist.6.c490)
dist.6.c490.dendro<- as.dendrogram(dist.6.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.6.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 2.5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

# Clustering - create distance matrix for 750 data
dist.6.750<-vegdist(main.6.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.6.750.clusters<-hclust(dist.6.750)
dist.6.750.dendro<- as.dendrogram(dist.6.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.6.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 2.5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.1,0))

##############################################################################################################
# 3 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.7.wide<-dcast(main.7, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.7.wide.c490 <- subset(main.7.wide, main.7.wide$wavelength=="c490")
main.7.wide.750 <- subset(main.7.wide, main.7.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.7.wide.c490.meta<-subset(main.7.wide.c490[c(1:3)])
main.7.wide.750.meta<-subset(main.7.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.7.wide.c490<-within(main.7.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.7.wide.c490.reduced<-subset(main.7.wide.c490[c(-1,-2,-3)])
main.7.wide.c490.reduced.names<-main.7.wide.c490.reduced[,-97]
rownames(main.7.wide.c490.reduced.names)<-main.7.wide.c490.reduced[,97]

main.7.wide.750<-within(main.7.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.7.wide.750.reduced<-subset(main.7.wide.750[c(-1,-2,-3)])
main.7.wide.750.reduced.names<-main.7.wide.750.reduced[,-97]
rownames(main.7.wide.750.reduced.names)<-main.7.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.7.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 3 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.7.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 3 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.7.wide.c490.reduced.names, main.7.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.7.wide.750.reduced.names, main.7.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.7.wide.750.reduced.names~main.7.wide.750.meta$ehb, data=main.7.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.7.wide.750.reduced.names, main.7.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.7.c490<-vegdist(main.7.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.7.c490.clusters<-hclust(dist.7.c490)
dist.7.c490.dendro<- as.dendrogram(dist.7.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.7.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 3 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.7.750<-vegdist(main.7.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.7.750.clusters<-hclust(dist.7.750)
dist.7.750.dendro<- as.dendrogram(dist.7.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.7.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 3 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.12,0))

##############################################################################################################
# 3.5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.8.wide<-dcast(main.8, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.8.wide.c490 <- subset(main.8.wide, main.8.wide$wavelength=="c490")
main.8.wide.750 <- subset(main.8.wide, main.8.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.8.wide.c490.meta<-subset(main.8.wide.c490[c(1:3)])
main.8.wide.750.meta<-subset(main.8.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.8.wide.c490<-within(main.8.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.8.wide.c490.reduced<-subset(main.8.wide.c490[c(-1,-2,-3)])
main.8.wide.c490.reduced.names<-main.8.wide.c490.reduced[,-97]
rownames(main.8.wide.c490.reduced.names)<-main.8.wide.c490.reduced[,97]

main.8.wide.750<-within(main.8.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.8.wide.750.reduced<-subset(main.8.wide.750[c(-1,-2,-3)])
main.8.wide.750.reduced.names<-main.8.wide.750.reduced[,-97]
rownames(main.8.wide.750.reduced.names)<-main.8.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.8.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 3.5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.8.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 3.5 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.8.wide.c490.reduced.names, main.8.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.8.wide.750.reduced.names, main.8.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.8.wide.750.reduced.names~main.8.wide.750.meta$ehb, data=main.8.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.8.wide.750.reduced.names, main.8.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.8.c490<-vegdist(main.8.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.8.c490.clusters<-hclust(dist.8.c490)
dist.8.c490.dendro<- as.dendrogram(dist.8.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.8.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 3.5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.8.750<-vegdist(main.8.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.8.750.clusters<-hclust(dist.8.750)
dist.8.750.dendro<- as.dendrogram(dist.8.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.8.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 3.5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

##############################################################################################################
# 4 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.9.wide<-dcast(main.9, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.9.wide.c490 <- subset(main.9.wide, main.9.wide$wavelength=="c490")
main.9.wide.750 <- subset(main.9.wide, main.9.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.9.wide.c490.meta<-subset(main.9.wide.c490[c(1:3)])
main.9.wide.750.meta<-subset(main.9.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.9.wide.c490<-within(main.9.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.9.wide.c490.reduced<-subset(main.9.wide.c490[c(-1,-2,-3)])
main.9.wide.c490.reduced.names<-main.9.wide.c490.reduced[,-97]
rownames(main.9.wide.c490.reduced.names)<-main.9.wide.c490.reduced[,97]

main.9.wide.750<-within(main.9.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.9.wide.750.reduced<-subset(main.9.wide.750[c(-1,-2,-3)])
main.9.wide.750.reduced.names<-main.9.wide.750.reduced[,-97]
rownames(main.9.wide.750.reduced.names)<-main.9.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.9.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 4 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.9.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 4 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.9.wide.c490.reduced.names, main.9.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.9.wide.750.reduced.names, main.9.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.9.wide.750.reduced.names~main.9.wide.750.meta$ehb, data=main.9.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.9.wide.750.reduced.names, main.9.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.9.c490<-vegdist(main.9.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.9.c490.clusters<-hclust(dist.9.c490)
dist.9.c490.dendro<- as.dendrogram(dist.9.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.9.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 4 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.9.750<-vegdist(main.9.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.9.750.clusters<-hclust(dist.9.750)
dist.9.750.dendro<- as.dendrogram(dist.9.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.9.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 4 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 4.5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.10.wide<-dcast(main.10, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.10.wide.c490 <- subset(main.10.wide, main.10.wide$wavelength=="c490")
main.10.wide.750 <- subset(main.10.wide, main.10.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.10.wide.c490.meta<-subset(main.10.wide.c490[c(1:3)])
main.10.wide.750.meta<-subset(main.10.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.10.wide.c490<-within(main.10.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.10.wide.c490.reduced<-subset(main.10.wide.c490[c(-1,-2,-3)])
main.10.wide.c490.reduced.names<-main.10.wide.c490.reduced[,-97]
rownames(main.10.wide.c490.reduced.names)<-main.10.wide.c490.reduced[,97]

main.10.wide.750<-within(main.10.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.10.wide.750.reduced<-subset(main.10.wide.750[c(-1,-2,-3)])
main.10.wide.750.reduced.names<-main.10.wide.750.reduced[,-97]
rownames(main.10.wide.750.reduced.names)<-main.10.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.10.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 4.5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.10.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 4.5 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.10.wide.c490.reduced.names, main.10.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.10.wide.750.reduced.names, main.10.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.10.wide.750.reduced.names~main.10.wide.750.meta$ehb, data=main.10.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.10.wide.750.reduced.names, main.10.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.10.c490<-vegdist(main.10.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.10.c490.clusters<-hclust(dist.10.c490)
dist.10.c490.dendro<- as.dendrogram(dist.10.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.10.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 4.5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.10.750<-vegdist(main.10.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.10.750.clusters<-hclust(dist.10.750)
dist.10.750.dendro<- as.dendrogram(dist.10.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.10.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 4.5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.11.wide<-dcast(main.11, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.11.wide.c490 <- subset(main.11.wide, main.11.wide$wavelength=="c490")
main.11.wide.750 <- subset(main.11.wide, main.11.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.11.wide.c490.meta<-subset(main.11.wide.c490[c(1:3)])
main.11.wide.750.meta<-subset(main.11.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.11.wide.c490<-within(main.11.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.11.wide.c490.reduced<-subset(main.11.wide.c490[c(-1,-2,-3)])
main.11.wide.c490.reduced.names<-main.11.wide.c490.reduced[,-97]
rownames(main.11.wide.c490.reduced.names)<-main.11.wide.c490.reduced[,97]

main.11.wide.750<-within(main.11.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.11.wide.750.reduced<-subset(main.11.wide.750[c(-1,-2,-3)])
main.11.wide.750.reduced.names<-main.11.wide.750.reduced[,-97]
rownames(main.11.wide.750.reduced.names)<-main.11.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.11.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.11.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 5 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.11.wide.c490.reduced.names, main.11.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.11.wide.750.reduced.names, main.11.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.11.wide.750.reduced.names~main.11.wide.750.meta$ehb, data=main.11.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.11.wide.750.reduced.names, main.11.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.11.c490<-vegdist(main.11.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.11.c490.clusters<-hclust(dist.11.c490)
dist.11.c490.dendro<- as.dendrogram(dist.11.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.11.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.11.750<-vegdist(main.11.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.11.750.clusters<-hclust(dist.11.750)
dist.11.750.dendro<- as.dendrogram(dist.11.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.11.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 5.5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.12.wide<-dcast(main.12, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.12.wide.c490 <- subset(main.12.wide, main.12.wide$wavelength=="c490")
main.12.wide.750 <- subset(main.12.wide, main.12.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.12.wide.c490.meta<-subset(main.12.wide.c490[c(1:3)])
main.12.wide.750.meta<-subset(main.12.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.12.wide.c490<-within(main.12.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.12.wide.c490.reduced<-subset(main.12.wide.c490[c(-1,-2,-3)])
main.12.wide.c490.reduced.names<-main.12.wide.c490.reduced[,-97]
rownames(main.12.wide.c490.reduced.names)<-main.12.wide.c490.reduced[,97]

main.12.wide.750<-within(main.12.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.12.wide.750.reduced<-subset(main.12.wide.750[c(-1,-2,-3)])
main.12.wide.750.reduced.names<-main.12.wide.750.reduced[,-97]
rownames(main.12.wide.750.reduced.names)<-main.12.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.12.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 5.5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.12.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 5.5 d")
text(ord.750, display = "species", col="black", bg="blue", cex=0.7)
points(ord.750, display = "species", pch=21, col="black", bg="blue", cex=0.7)

# ANOSIM on the effect of EHB for c490 data
anosim(main.12.wide.c490.reduced.names, main.12.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.12.wide.750.reduced.names, main.12.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.12.wide.750.reduced.names~main.12.wide.750.meta$ehb, data=main.12.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.12.wide.750.reduced.names, main.12.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.12.c490<-vegdist(main.12.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.12.c490.clusters<-hclust(dist.12.c490)
dist.12.c490.dendro<- as.dendrogram(dist.12.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.12.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 5.5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.12.750<-vegdist(main.12.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.12.750.clusters<-hclust(dist.12.750)
dist.12.750.dendro<- as.dendrogram(dist.12.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.12.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 5.5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 6 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.13.wide<-dcast(main.13, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.13.wide.c490 <- subset(main.13.wide, main.13.wide$wavelength=="c490")
main.13.wide.750 <- subset(main.13.wide, main.13.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.13.wide.c490.meta<-subset(main.13.wide.c490[c(1:3)])
main.13.wide.750.meta<-subset(main.13.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.13.wide.c490<-within(main.13.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.13.wide.c490.reduced<-subset(main.13.wide.c490[c(-1,-2,-3)])
main.13.wide.c490.reduced.names<-main.13.wide.c490.reduced[,-97]
rownames(main.13.wide.c490.reduced.names)<-main.13.wide.c490.reduced[,97]

main.13.wide.750<-within(main.13.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.13.wide.750.reduced<-subset(main.13.wide.750[c(-1,-2,-3)])
main.13.wide.750.reduced.names<-main.13.wide.750.reduced[,-97]
rownames(main.13.wide.750.reduced.names)<-main.13.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.13.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 6 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.13.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 6 d")

# ANOSIM on the effect of EHB for c490 data
anosim(main.13.wide.c490.reduced.names, main.13.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.13.wide.750.reduced.names, main.13.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.13.wide.750.reduced.names~main.13.wide.750.meta$ehb, data=main.13.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.13.wide.750.reduced.names, main.13.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.13.c490<-vegdist(main.13.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.13.c490.clusters<-hclust(dist.13.c490)
dist.13.c490.dendro<- as.dendrogram(dist.13.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.13.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 6 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.13.750<-vegdist(main.13.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.13.750.clusters<-hclust(dist.13.750)
dist.13.750.dendro<- as.dendrogram(dist.13.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.13.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 6 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 6.5 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.14.wide<-dcast(main.14, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.14.wide.c490 <- subset(main.14.wide, main.14.wide$wavelength=="c490")
main.14.wide.750 <- subset(main.14.wide, main.14.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.14.wide.c490.meta<-subset(main.14.wide.c490[c(1:3)])
main.14.wide.750.meta<-subset(main.14.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.14.wide.c490<-within(main.14.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.14.wide.c490.reduced<-subset(main.14.wide.c490[c(-1,-2,-3)])
main.14.wide.c490.reduced.names<-main.14.wide.c490.reduced[,-97]
rownames(main.14.wide.c490.reduced.names)<-main.14.wide.c490.reduced[,97]

main.14.wide.750<-within(main.14.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.14.wide.750.reduced<-subset(main.14.wide.750[c(-1,-2,-3)])
main.14.wide.750.reduced.names<-main.14.wide.750.reduced[,-97]
rownames(main.14.wide.750.reduced.names)<-main.14.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.14.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 6.5 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.14.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 6.5 d")
text(ord.750, display = "species", col="black", bg="blue", cex=0.7)
points(ord.750, display = "species", pch=21, col="black", bg="blue", cex=0.7)

# ANOSIM on the effect of EHB for c490 data
anosim(main.14.wide.c490.reduced.names, main.14.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.14.wide.750.reduced.names, main.14.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.14.wide.750.reduced.names~main.14.wide.750.meta$ehb, data=main.14.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.14.wide.750.reduced.names, main.14.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.14.c490<-vegdist(main.14.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.14.c490.clusters<-hclust(dist.14.c490)
dist.14.c490.dendro<- as.dendrogram(dist.14.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.14.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 6.5 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.14.750<-vegdist(main.14.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.14.750.clusters<-hclust(dist.14.750)
dist.14.750.dendro<- as.dendrogram(dist.14.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.14.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 6.5 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################################################################################
# 7 days
##############################################################################################################

# Convert data from long to wide - for analysis in vegan
main.15.wide<-dcast(main.15, ehb + plate.f + wavelength ~ substrate, value.var = "gross.abs")

# Separate two wavelengths into two matrices
main.15.wide.c490 <- subset(main.15.wide, main.15.wide$wavelength=="c490")
main.15.wide.750 <- subset(main.15.wide, main.15.wide$wavelength=="750")

# Copy metadata columns to a new metadata matrix
main.15.wide.c490.meta<-subset(main.15.wide.c490[c(1:3)])
main.15.wide.750.meta<-subset(main.15.wide.750[c(1:3)])

# Remove metadata columns from "abundance" matrices
main.15.wide.c490<-within(main.15.wide.c490,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.15.wide.c490.reduced<-subset(main.15.wide.c490[c(-1,-2,-3)])
main.15.wide.c490.reduced.names<-main.15.wide.c490.reduced[,-97]
rownames(main.15.wide.c490.reduced.names)<-main.15.wide.c490.reduced[,97]

main.15.wide.750<-within(main.15.wide.750,  treatment <- paste(ehb, plate.f, wavelength, sep="_"))
main.15.wide.750.reduced<-subset(main.15.wide.750[c(-1,-2,-3)])
main.15.wide.750.reduced.names<-main.15.wide.750.reduced[,-97]
rownames(main.15.wide.750.reduced.names)<-main.15.wide.750.reduced[,97]

# NMS ordination for 490 data
ord.c490<-metaMDS(main.15.wide.c490.reduced.names, trymax=100) # must have vegan loaded
ord.c490
ordipointlabel(ord.c490, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at c490 nm after 7 days")

# NMS ordination for 750 data
ord.750<-metaMDS(main.15.wide.750.reduced.names, trymax=100) # must have vegan loaded
ord.750
ordipointlabel(ord.750, display = "sites", pch=21, col="black", bg="red", cex=0.8, main="Substrate use at 750 nm after 7 d")
text(ord.750, display = "species", col="black", bg="blue", cex=0.7)
points(ord.750, display = "species", pch=21, col="black", bg="blue", cex=0.7)

# ANOSIM on the effect of EHB for c490 data
anosim(main.15.wide.c490.reduced.names, main.15.wide.c490.meta$ehb, permutations=999, distance="bray")

# ANOSIM on the effect of EHB for 750 data
anosim(main.15.wide.750.reduced.names, main.15.wide.750.meta$ehb, permutations=999, distance="bray")

# PerMANOVA on the effect of EHB for 750 data
adonis(main.15.wide.750.reduced.names~main.15.wide.750.meta$ehb, data=main.15.wide.750.meta, permutations=999, distance="bray")

# MRPP on the effect of EHB for 750 data
mrpp(main.15.wide.750.reduced.names, main.15.wide.750.meta$ehb, permutations=999, distance="bray")

# Clustering - create distance matrix for c490 data
dist.15.c490<-vegdist(main.15.wide.c490.reduced.names, method="bray")

# Clustering - create dendrogram for c490 data
dist.15.c490.clusters<-hclust(dist.15.c490)
dist.15.c490.dendro<- as.dendrogram(dist.15.c490.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.15.c490.dendro, hang=-1), horiz = TRUE, main="Substrate use at 7 d, c490", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.15,0))

# Clustering - create distance matrix for 750 data
dist.15.750<-vegdist(main.15.wide.750.reduced.names, method="bray")

# Clustering - create dendrogram for 750 data
dist.15.750.clusters<-hclust(dist.15.750)
dist.15.750.dendro<- as.dendrogram(dist.15.750.clusters)
par(mar = c(5,5,5,10), lwd=3, cex=1.3)
plot(hang.dendrogram(dist.15.750.dendro, hang=-1), horiz = TRUE, main="Substrate use at 7 d, 750", xlab="Bray-Curtis Dissimilarity", cex.main=1.5, cex.lab=1.5, xlim=c(.2,0))

##############################################END OF SECTION##################################################

##############################################END OF SCRIPT###################################################

##############################################################################################################
